from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters
from handlers import start, button_handler, message_handler, admin_check, leaderboard, history, reset_balance_cmd, approve_handler, reject_handler
from flask_app import run_web, keep_alive_worker
import threading, signal, sys
from database import init_db
from config import BOT_TOKEN

def signal_handler(sig, frame):
    print('🔌 Graceful shutdown...')
    sys.exit(0)

def main():
    print("🚀 Launching bot...")
    init_db()

    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    threading.Thread(target=run_web, daemon=True).start()
    threading.Thread(target=keep_alive_worker, daemon=True).start()

    app = Application.builder().token(BOT_TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("leaderboard", leaderboard))
    app.add_handler(CommandHandler("history", history))
    app.add_handler(CommandHandler("admin", admin_check))
    app.add_handler(CommandHandler("resetbalance", reset_balance_cmd))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.add_handler(CallbackQueryHandler(approve_handler, pattern="^approve_"))
    app.add_handler(CallbackQueryHandler(reject_handler, pattern="^reject_"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    print("✅ Bot is now running.")
    app.run_polling(drop_pending_updates=True)

if __name__ == "__main__":
    main()